<div align="center">
    <a href="https://github.com/raminxz/raminxz.github.io/edit/main/index.html">
        <img align="center" src="https://raw.githubusercontent.com/raminxz/svg/b94bc695f2dc3da3ac9d1e2a7cf68fc073efbfb8/raminxz-center.svg" />
    </a>
</div>

***
|    |    |    |    |    |    |    |    |    |
|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|

|*Index*|[open](https://github.com/raminxz/raminxz.github.io/blob/main/index.html)|[edit](https://github.com/raminxz/raminxz.github.io/edit/main/index.html)|
|:--:|:--:|:--:|

|
 <a href="https://raminxz.github.io/">
<img src="https://raw.githubusercontent.com/iranset/iranset.github.io/a506c379f67c5b5bcab79eac57be2a6ee949461f/svgs/solid/globe.svg" width="16" height="16" alt="site" title="site"/> نمایش وبسایت
</a>
|
<a class="" href="https://github.com/raminxz/raminxz.github.io/archive/refs/heads/main.zip">
  <img src="https://raw.githubusercontent.com/iranset/iranset.github.io/main/svgs/solid/download.svg" width="16" height="16" title="download" alt="download" /> دانلود مخزن 
</a>
|


|    |    |    |    |    |    |    |    |    |
|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|:--:|
