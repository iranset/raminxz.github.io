<div align="center">
    <a href="#">
        <img align="center" src="https://raw.githubusercontent.com/raminxz/svg/b94bc695f2dc3da3ac9d1e2a7cf68fc073efbfb8/raminxz-center.svg" />
    </a>
</div>

# min
|folder|for|
|:-----|:--:|
|[css](https://github.com/raminxz/raminxz.github.io/tree/main/css)||
|[Img](https://github.com/raminxz/raminxz.github.io/tree/main/img)||

